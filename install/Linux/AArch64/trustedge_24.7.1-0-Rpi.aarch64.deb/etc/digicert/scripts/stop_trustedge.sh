#!/bin/bash

pkill -15 trustedge
